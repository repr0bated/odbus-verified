import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Renderer } from "@json-render/react";
import { chatRegistry } from "../catalog/chat-registry";
import { JsonRenderProvider } from "../runtime/JsonRenderProvider";
import { dashboardReferences } from "./dashboard-examples";
import { readCanvasResponse, validateCanvasSpec } from "./canvas-contract";
import { catalogPresentationMessage, referenceChatResponse } from "./reference-chat";

const sample = { root: "notice", elements: { notice: { type: "dashboardStatus", props: { label: "Example", tone: "info" } } } };

describe("dashboard references", () => {
  it("covers all menu entries, renders every example, and records source placeholders", () => {
    expect(dashboardReferences).toHaveLength(46);
    expect(dashboardReferences.filter(item => item.placeholder)).toHaveLength(4);
    for (const item of dashboardReferences) {
      expect(() => validateCanvasSpec(item.spec), item.id).not.toThrow();
      const markup = renderToStaticMarkup(<JsonRenderProvider><Renderer spec={item.spec} registry={chatRegistry} /></JsonRenderProvider>);
      expect(markup, item.id).toContain("Static reference");
      expect(markup, item.id).not.toContain("Unknown component");
    }
  });
  it("exposes an explicit reference command without treating ordinary chat as a command", () => {
    expect(referenceChatResponse("/ui-reference btrfs")?.canvasSpec).toBeDefined();
    expect(referenceChatResponse("/ui-reference")?.message.content).toContain("live-trace");
    expect(referenceChatResponse("what is btrfs")).toBeUndefined();
    expect(catalogPresentationMessage("show btrfs", "personal")).toContain("Relevant static reference (btrfs)");
    expect(catalogPresentationMessage("show btrfs", "ui_render")).toContain("gallery for proposing possible interfaces");
  });
  it("renders only catalog-valid fenced output", () => {
    expect(readCanvasResponse(`Example\n\`\`\`json-render\n${JSON.stringify(sample)}\n\`\`\``)).toEqual({ content: "Example", canvasSpec: sample });
    expect(readCanvasResponse("plain reply")).toEqual({ content: "plain reply" });
    expect(readCanvasResponse("```json-render\n{bad}\n```").canvasSpec).toBeUndefined();
  });
  it("rejects actions, runtime controls, undeclared props and dynamic bindings", () => {
    for (const invalid of [
      { ...sample, state: {} },
      { root: "notice", elements: { notice: { ...sample.elements.notice, on: { press: { action: "invoke" } } } } },
      { root: "notice", elements: { notice: { type: "antigravityChatContainer", props: {} } } },
      { root: "notice", elements: { notice: { ...sample.elements.notice, props: { ...sample.elements.notice.props, html: "<script>" } } } },
      { root: "notice", elements: { notice: { ...sample.elements.notice, props: { ...sample.elements.notice.props, label: { $state: "/secret" } } } } },
    ]) expect(() => validateCanvasSpec(invalid)).toThrow();
  });
  it("rejects cyclic, missing, shared and unreachable children", () => {
    for (const children of [["notice"], ["missing"]]) expect(() => validateCanvasSpec({ root: "notice", elements: { notice: { ...sample.elements.notice, children } } })).toThrow();
    expect(() => validateCanvasSpec({ root: "notice", elements: { ...sample.elements, extra: sample.elements.notice } })).toThrow();
    expect(() => validateCanvasSpec({ root: "root", elements: { root: { type: "container", props: { className: null }, children: ["notice", "notice"] }, ...sample.elements } })).toThrow();
  });
});
