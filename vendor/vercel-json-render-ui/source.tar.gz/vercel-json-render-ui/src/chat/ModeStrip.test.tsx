import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { ChatAdapter } from "./chat-adapter";
import type { ProjectSummary, ResolvedChatContext } from "./chat-mode";
import { ModeStrip } from "./ModeStrip";

const personal: ResolvedChatContext = {
  mode: "personal",
  session_id: "own-session",
  project_id: null,
  memory_namespace: "session/own-session/personal",
  read_only: false,
  effective_capabilities: ["chat.context"],
  allowed_agents: [],
  selected_agent: null,
};

function doorAdapter(projects: ProjectSummary[] = [], context: ResolvedChatContext = personal) {
  const getChatContext = vi.fn().mockResolvedValue(context);
  const listProjects = vi.fn().mockResolvedValue(projects);
  const selectChatMode = vi.fn().mockImplementation(async ({ mode }: { mode: string }) => ({
    ...personal,
    mode,
    memory_namespace: mode === "ui_render" ? "" : `session/own-session/${mode}`,
  }));
  const adapter = { kind: "remote", getChatContext, listProjects, selectChatMode } as unknown as ChatAdapter;
  return { adapter, getChatContext, listProjects, selectChatMode };
}

afterEach(() => cleanup());

describe("ModeStrip", () => {
  it("shows loading and Personal, but hides Project when no ready project exists", async () => {
    const { adapter } = doorAdapter();
    render(<ModeStrip adapter={adapter} />);
    expect(screen.getByRole("status")).toHaveTextContent("Loading chat mode");

    const selector = await screen.findByRole("combobox", { name: "Mode" });
    expect(selector).toHaveValue("personal");
    expect(screen.getAllByRole("option").map((option) => option.textContent)).toEqual([
      "Personal", "Control plane", "Accountability", "NotebookLM", "UI render",
    ]);
    expect(screen.getByText("session/own-session/personal")).toBeInTheDocument();
  });

  it("requires choosing a ready accessible project before selecting Project mode", async () => {
    const { adapter, selectChatMode } = doorAdapter([
      { project_id: "pending", title: "Pending", status: "provisioning" },
      { project_id: "ready", title: "Ready project", status: "ready" },
    ]);
    render(<ModeStrip adapter={adapter} />);
    const mode = await screen.findByRole("combobox", { name: "Mode" });
    expect(await screen.findByRole("option", { name: "Project" })).toBeInTheDocument();

    fireEvent.change(mode, { target: { value: "project" } });
    expect(selectChatMode).not.toHaveBeenCalled();
    expect(screen.getByRole("status")).toHaveTextContent("Personal remains active");
    const project = screen.getByRole("combobox", { name: "Project" });
    expect(project).toHaveValue("");
    expect(screen.queryByRole("option", { name: "Pending" })).not.toBeInTheDocument();
    fireEvent.change(project, { target: { value: "ready" } });
    expect(selectChatMode).toHaveBeenCalledWith({ mode: "project", projectId: "ready", personalNamespace: undefined });
    expect(await screen.findByText("session/own-session/project")).toBeInTheDocument();
  });

  it("continues to show a server-selected project if the project list no longer includes it", async () => {
    const context: ResolvedChatContext = {
      ...personal,
      mode: "project",
      project_id: "former",
      memory_namespace: "project/former",
    };
    const { adapter } = doorAdapter([], context);
    render(<ModeStrip adapter={adapter} />);

    expect(await screen.findByRole("combobox", { name: "Mode" })).toHaveValue("project");
    expect(screen.getByRole("combobox", { name: "Project" })).toHaveValue("former");
    expect(screen.getByRole("option", { name: "Current project (former)" })).toBeInTheDocument();
  });

  it("shows a failed context read and retries without inventing a Personal selection", async () => {
    const { adapter, getChatContext } = doorAdapter();
    getChatContext.mockRejectedValueOnce(new Error("Context temporarily unavailable"));
    render(<ModeStrip adapter={adapter} />);

    expect(await screen.findByRole("alert")).toHaveTextContent("Context temporarily unavailable");
    expect(screen.queryByRole("combobox", { name: "Mode" })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Retry chat mode" }));
    expect(await screen.findByRole("combobox", { name: "Mode" })).toHaveValue("personal");
    expect(getChatContext).toHaveBeenCalledTimes(2);
  });

  it("keeps the current mode when the door refuses a selection", async () => {
    const { adapter, selectChatMode } = doorAdapter();
    selectChatMode.mockRejectedValueOnce(new Error("Control-plane grant required"));
    render(<ModeStrip adapter={adapter} />);
    const selector = await screen.findByRole("combobox", { name: "Mode" });

    fireEvent.change(selector, { target: { value: "control_plane" } });
    expect(await screen.findByRole("alert")).toHaveTextContent("Control-plane grant required");
    expect(selector).toHaveValue("personal");

    fireEvent.change(selector, { target: { value: "accountability" } });
    expect(await screen.findByText("session/own-session/accountability")).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });
});
