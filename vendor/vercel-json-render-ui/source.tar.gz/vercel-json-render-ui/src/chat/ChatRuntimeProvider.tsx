import {
  createContext,
  useContext,
  useState,
  type ReactNode,
} from "react";
import type { Spec } from "@json-render/core";
import type {
  ChatAdapter,
  ProviderOption,
  RouteSelection,
} from "./chat-adapter";
import { initialCanvasSpec } from "./local-chat-adapter";
import type { ResolvedChatContext } from "./chat-mode";

interface ChatRuntimeValue {
  adapter: ChatAdapter;
  providers: ProviderOption[];
  route: RouteSelection;
  routePending: boolean;
  routeError: string | null;
  chatContext: ResolvedChatContext | null;
  scopeKey: string;
  setChatContext: (context: ResolvedChatContext) => void;
  canvasSpec: Spec;
  setCanvasSpec: (spec: Spec) => void;
  selectProvider: (providerId: string) => Promise<void>;
  selectModel: (modelId: string) => Promise<void>;
}

const ChatRuntimeContext = createContext<ChatRuntimeValue | null>(null);

/** The door's resolved session scope is the authority for both thread and Canvas. */
export function chatScopeKey(context: ResolvedChatContext | null, remote: boolean): string {
  if (!remote) return "local";
  if (!context) return "awaiting-door";
  return encodeURIComponent(JSON.stringify([
    context.session_id,
    context.mode,
    context.project_id,
    context.memory_namespace,
  ]));
}

export function chatMessagesPath(streamId: string, scopeKey: string): string {
  return `/streams/${streamId}/scopes/${scopeKey}/messages`;
}

export function ChatRuntimeProvider({
  adapter,
  children,
}: {
  adapter: ChatAdapter;
  children: ReactNode;
}) {
  const firstProvider = adapter.providers[0];
  const firstModel = firstProvider?.models[0];
  if (!firstProvider || !firstModel) {
    throw new Error("ChatAdapter must expose at least one provider and model.");
  }

  const [route, setRoute] = useState<RouteSelection>({
    providerId: firstProvider.id,
    modelId: firstModel.id,
  });
  const [routePending, setRoutePending] = useState(false);
  const [routeError, setRouteError] = useState<string | null>(null);
  const [chatContext, setChatContext] = useState<ResolvedChatContext | null>(null);
  const [canvasByScope, setCanvasByScope] = useState<Map<string, Spec>>(() => new Map());
  const scopeKey = chatScopeKey(chatContext, adapter.kind === "remote");
  const canvasSpec = canvasByScope.get(scopeKey) ?? initialCanvasSpec;
  const setCanvasSpec = (spec: Spec) => {
    setCanvasByScope(previous => new Map(previous).set(scopeKey, spec));
  };

  const commitRoute = async (next: RouteSelection) => {
    setRoutePending(true);
    setRouteError(null);
    try {
      setRoute(await adapter.selectRoute(next));
    } catch (error) {
      setRouteError(error instanceof Error ? error.message : "Route selection failed.");
    } finally {
      setRoutePending(false);
    }
  };

  const value: ChatRuntimeValue = {
    adapter,
    providers: adapter.providers,
    route,
    routePending,
    routeError,
    chatContext,
    scopeKey,
    setChatContext,
    canvasSpec,
    setCanvasSpec,
    selectProvider: async (providerId) => {
      const provider = adapter.providers.find((entry) => entry.id === providerId);
      const model = provider?.models[0];
      if (!provider || !model) return;
      await commitRoute({ providerId: provider.id, modelId: model.id });
    },
    selectModel: async (modelId) => {
      await commitRoute({ ...route, modelId });
    },
  };

  return <ChatRuntimeContext.Provider value={value}>{children}</ChatRuntimeContext.Provider>;
}

export function useChatRuntime(): ChatRuntimeValue {
  const value = useContext(ChatRuntimeContext);
  if (!value) {
    throw new Error("useChatRuntime must be used inside ChatRuntimeProvider.");
  }
  return value;
}
