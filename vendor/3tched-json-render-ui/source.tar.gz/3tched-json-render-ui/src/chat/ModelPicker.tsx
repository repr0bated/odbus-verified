import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useChatRuntime } from "./ChatRuntimeProvider";
import { CHAT_MODES } from "./chat-mode";
import type { ProviderOption, RouteSelection } from "./chat-adapter";
import type { DoorChatAdapter } from "./door-chat-adapter";
import { ControlPlaneMutationUnconfirmedError } from "./control-plane-model";
import { useSudoPrompt } from "./SudoPrompt";

/** Presentation uses only the adapter's selection boundary. */
export function ModelPicker({ className = "" }: { className?: string | null }) {
  const runtime = useChatRuntime();
  const remote = runtime.adapter.kind === "remote";
  if (remote && !runtime.chatContext) return null;
  return <ScopedModelPicker key={runtime.scopeKey} className={className ?? ""} />;
}

function ScopedModelPicker({ className }: { className: string }) {
  const { adapter, chatContext } = useChatRuntime();
  const remote = adapter.kind === "remote";
  const mode = CHAT_MODES.find(entry => entry.id === chatContext?.mode)?.label ?? "Local";
  return <section className={`routing-strip model-picker ${className}`} aria-label={remote ? "Router model selection" : "Local model routing"}>
    <div className="routing-strip__label">
      <span>{mode} model</span>
      <small>{chatContext?.mode === "control_plane" ? "protected change · root password per task" : remote ? "router selection" : "offline workspace"}</small>
    </div>
    {remote && chatContext?.mode === "control_plane"
      ? <ControlPlanePicker adapter={adapter as DoorChatAdapter} />
      : <RoutePicker />}
    {adapter.recoverConversation ? <ConversationRecovery /> : null}
  </section>;
}

function ConversationRecovery() {
  const { adapter } = useChatRuntime();
  const active = useRef<typeof adapter | null>(adapter);
  useLayoutEffect(() => {
    active.current = adapter;
    return () => { active.current = null; };
  }, [adapter]);
  const [state, setState] = useState({ pending: false, error: null as string | null, recovered: false });
  const recover = async () => {
    if (state.pending || active.current !== adapter || !adapter.recoverConversation) return;
    setState({ pending: true, error: null, recovered: false });
    try {
      await adapter.recoverConversation();
      if (active.current === adapter) setState({ pending: false, error: null, recovered: true });
    } catch (cause) {
      if (active.current === adapter) setState({ pending: false, error: cause instanceof Error ? cause.message : "Conversation recovery failed.", recovered: false });
    }
  };
  return <div className="model-picker__state">
    <div className="route-catalog model-picker__actions"><button type="button" disabled={state.pending} onClick={() => void recover()}>{state.pending ? "Recovering conversation…" : "Recover conversation"}</button></div>
    {state.recovered ? <p className="route-status" role="status">Conversation recovered. Send your message again.</p> : null}
    {state.error ? <p className="route-status route-status--error" role="alert">Conversation recovery: {state.error}</p> : null}
  </div>;
}

function selectionLabel(selection: RouteSelection, providers: ReturnType<typeof useChatRuntime>["providers"]) {
  const provider = providers.find(entry => entry.id === selection.providerId);
  const model = provider?.models.find(entry => entry.id === selection.modelId);
  return `${provider?.label ?? selection.providerId} / ${model?.label ?? selection.modelId}`;
}

function RoutePicker() {
  const { adapter, providers, route, routeAttempt, routeConfirmed, routeError, routePending, catalogPending, catalogError, refreshProviders, applyRoute } = useChatRuntime();
  const [draftState, setDraftState] = useState({ adapter, route });
  const draft = draftState.adapter === adapter ? draftState.route : route;
  const setDraft = (selection: RouteSelection) => setDraftState({ adapter, route: selection });
  const valid = providers.find(entry => entry.id === draft.providerId)?.models.some(entry => entry.id === draft.modelId) ?? false;
  const changed = draft.providerId !== route.providerId || draft.modelId !== route.modelId;
  return <>
    <RouteFields providers={providers} draft={draft} setDraft={setDraft} disabled={routePending} refresh={refreshProviders} />
    <div className="route-catalog model-picker__actions">
      <button type="button" disabled={routePending || !valid || (routeConfirmed && !changed)} onClick={() => void applyRoute(draft)}>
        {routePending ? "Applying…" : "Apply model"}
      </button>
      {adapter.refreshProviders ? <button type="button" disabled={catalogPending} onClick={() => void refreshProviders()}>{catalogPending ? "Refreshing…" : "Refresh models"}</button> : null}
    </div>
    <div className="model-picker__state">
      <p className="model-picker__current"><span>{routeConfirmed ? "Last applied" : "Not applied"}</span>{routeConfirmed ? selectionLabel(route, providers) : "Choose a model and apply to confirm the route."}</p>
      <p className="route-status" role="status" aria-live="polite">
        {routePending ? `Applying ${selectionLabel(routeAttempt ?? draft, providers)}` : changed ? `Pending: ${selectionLabel(draft, providers)}` : adapter.kind === "local" ? "Local selection · no network calls" : "Apply confirms the router selection"}
      </p>
      {routeError ? <p className="route-status route-status--error" role="alert">Could not apply {selectionLabel(routeAttempt ?? draft, providers)}: {routeError}</p> : null}
      {catalogError ? <p className="route-status route-status--error" role="alert">Model catalog: {catalogError}</p> : null}
      {!providers.length ? <p className="route-status">No provider is configured.</p> : null}
    </div>
  </>;
}

/** All modes use the exact same provider/model choices from the runtime catalog. */
function RouteFields({ providers, draft, setDraft, disabled, refresh }: {
  providers: ProviderOption[];
  draft: RouteSelection;
  setDraft: (selection: RouteSelection) => void;
  disabled: boolean;
  refresh: () => Promise<void>;
}) {
  const provider = providers.find(entry => entry.id === draft.providerId);
  const models = provider?.models ?? [];
  const valid = models.some(entry => entry.id === draft.modelId);
  return <>
    <label><span>Provider</span>
      <select value={draft.providerId} onFocus={() => void refresh()} disabled={disabled || !providers.length}
        onChange={event => {
          const next = providers.find(entry => entry.id === event.target.value);
          if (next) setDraft({ providerId: next.id, modelId: next.models[0]?.id ?? "" });
        }}>
        {!providers.length ? <option value="">No providers available</option> : null}
        {providers.length > 0 && !provider ? <option value={draft.providerId} disabled>{draft.providerId} (no longer listed)</option> : null}
        {providers.map(entry => <option key={entry.id} value={entry.id}>{entry.label}</option>)}
      </select>
    </label>
    <label className="model-select"><span>Model</span>
      <select value={models.length ? draft.modelId : ""} onFocus={() => void refresh()} disabled={disabled || !models.length}
        onChange={event => setDraft({ ...draft, modelId: event.target.value })}>
        {!models.length ? <option value="">No models for this provider yet</option> : null}
        {models.length > 0 && !valid ? <option value={draft.modelId} disabled>{draft.modelId || "Select a model"} (no longer listed)</option> : null}
        {models.map(entry => <option key={entry.id} value={entry.id}>{entry.label}</option>)}
      </select>
    </label>
  </>;
}

function sameSelection(left: RouteSelection | null, right: RouteSelection) {
  return left?.providerId === right.providerId && left.modelId === right.modelId;
}

/** A draft belongs to the catalog; an observed native route may not. */
function catalogDraft(providers: ProviderOption[], preferred: RouteSelection | null, fallback: RouteSelection): RouteSelection {
  const preferredProvider = providers.find(entry => entry.id === preferred?.providerId);
  if (preferredProvider?.models.some(model => model.id === preferred?.modelId)) return preferred!;
  if (preferredProvider?.models[0]) return { providerId: preferredProvider.id, modelId: preferredProvider.models[0].id };
  const fallbackProvider = providers.find(entry => entry.id === fallback.providerId);
  if (fallbackProvider?.models.some(model => model.id === fallback.modelId)) return fallback;
  const first = providers.find(entry => entry.models.length > 0) ?? providers[0];
  return { providerId: first?.id ?? "", modelId: first?.models[0]?.id ?? "" };
}

function ControlPlanePicker({ adapter }: { adapter: DoorChatAdapter }) {
  const { providers, route, catalogPending, catalogError, refreshProviders } = useChatRuntime();
  const control = adapter.controlPlane;
  const latestProviders = useRef(providers);
  useLayoutEffect(() => { latestProviders.current = providers; }, [providers]);
  const active = useRef<DoorChatAdapter | null>(adapter);
  useLayoutEffect(() => {
    active.current = adapter;
    return () => { active.current = null; };
  }, [adapter]);
  const [state, setState] = useState({ adapter, current: null as RouteSelection | null, draft: route, draftEdited: false, loading: true, pending: false, error: null as string | null, attempt: null as RouteSelection | null, unconfirmed: false, writeAccepted: false });
  const [refresh, setRefresh] = useState(0);
  const [elevate, sudoPrompt] = useSudoPrompt(adapter.authorizeTask);
  useEffect(() => {
    let active = true;
    if (!control) return;
    void control.current().then(current => {
      if (active) setState(previous => ({ ...previous, adapter, current, draft: previous.adapter === adapter && previous.draftEdited ? previous.draft : catalogDraft(latestProviders.current, current, previous.draft), loading: false, pending: false, error: null, attempt: null, unconfirmed: false, writeAccepted: false }));
    }).catch((error: unknown) => {
      if (active) setState(previous => ({ ...previous, adapter, loading: false, error: error instanceof Error ? error.message : "Control Plane current model lookup failed." }));
    });
    return () => { active = false; };
  }, [adapter, control, refresh]);
  const currentState = state.adapter === adapter ? state : { ...state, current: null, draft: route, draftEdited: false, loading: true, pending: false, error: null, attempt: null, unconfirmed: false, writeAccepted: false };
  const label = (selection: RouteSelection) => selectionLabel(selection, providers);
  const draft = catalogDraft(providers, currentState.draftEdited ? currentState.draft : currentState.current, currentState.draft);
  const valid = providers.find(entry => entry.id === draft.providerId)?.models.some(entry => entry.id === draft.modelId) ?? false;
  const currentInCatalog = currentState.current ? providers.find(entry => entry.id === currentState.current!.providerId)?.models.some(entry => entry.id === currentState.current!.modelId) ?? false : false;
  const apply = async () => {
    if (!control || currentState.pending || currentState.unconfirmed || !valid) return;
    const attempt = draft;
    setState(previous => ({ ...previous, pending: true, error: null, attempt, writeAccepted: false, unconfirmed: false }));
    try {
      await control.set(attempt, async (...args) => {
        if (active.current !== adapter) throw new Error("Model selection context changed.");
        await elevate(...args);
        if (active.current !== adapter) throw new Error("Model selection context changed.");
      });
    } catch (cause) {
      if (active.current !== adapter) return;
      setState(previous => ({ ...previous, pending: false, unconfirmed: cause instanceof ControlPlaneMutationUnconfirmedError, error: cause instanceof Error ? cause.message : "Control Plane model selection failed." }));
      return;
    }
    if (active.current !== adapter) return;
    setState(previous => ({ ...previous, writeAccepted: true, unconfirmed: true }));
    try {
      const current = await control.current();
      if (active.current !== adapter) return;
      setState(previous => ({ ...previous, current, pending: false, unconfirmed: false, error: sameSelection(current, attempt) ? null : "The returned current model differs from the requested provider and model." }));
    } catch (cause) {
      if (active.current !== adapter) return;
      setState(previous => ({ ...previous, pending: false, unconfirmed: true, error: cause instanceof Error ? cause.message : "Current Control Plane model readback failed." }));
    }
  };
  const reload = async () => {
    if (control) setState(previous => ({ ...previous, loading: true, error: null }));
    await refreshProviders();
    if (active.current !== adapter) return;
    // Resolve the native route against the refreshed shared catalog.
    if (control) setRefresh(previous => previous + 1);
  };
  return <>
    <RouteFields providers={providers} draft={draft} setDraft={draft => setState(previous => ({ ...previous, draft, draftEdited: true }))} disabled={(!!control && currentState.loading) || currentState.pending} refresh={refreshProviders} />
    <div className="route-catalog model-picker__actions">
      <button type="button" disabled={!control || currentState.loading || currentState.pending || currentState.unconfirmed || sameSelection(currentState.current, draft) || !valid} onClick={() => void apply()}>{currentState.pending ? "Applying…" : "Apply Control Plane model"}</button>
      <button type="button" disabled={(!!control && currentState.loading) || currentState.pending || catalogPending} onClick={() => void reload()}>{catalogPending ? "Refreshing…" : "Refresh models"}</button>
    </div>
    <div className="model-picker__state">
      <p className="model-picker__current"><span>Current model</span>{!control ? "Unavailable through this identity's adapter" : currentState.loading ? "Reading current model…" : currentState.unconfirmed ? "Unconfirmed · refresh to read current model" : currentState.current ? label(currentState.current) : "Current model was not returned"}</p>
      <p className="route-status" role="status" aria-live="polite">{!control ? "Control Plane model selection is unavailable through this identity's adapter." : currentState.pending ? `Applying ${label(currentState.attempt ?? draft)}` : currentState.unconfirmed && currentState.attempt ? `${currentState.writeAccepted ? "Change sent" : "Change outcome unknown"} for ${label(currentState.attempt)}; current model unconfirmed. Refresh before applying another model.` : "Changing the Control Plane model requires a root password for this task."}</p>
      {currentState.error ? <p className="route-status route-status--error" role="alert">{currentState.attempt ? currentState.unconfirmed ? `${currentState.writeAccepted ? "Change sent" : "Change outcome unknown"} for ${label(currentState.attempt)}; current model unconfirmed: ` : currentState.writeAccepted ? `Change sent for ${label(currentState.attempt)}; readback differs: ` : `Could not apply ${label(currentState.attempt)}: ` : "Control Plane model: "}{currentState.error}</p> : null}
      {currentState.current && !currentInCatalog && !currentState.loading && !currentState.unconfirmed ? <p className="route-status">Current route is not in the shared catalog. Choose a catalog model to change it.</p> : null}
      {catalogError ? <p className="route-status route-status--error" role="alert">Model catalog: {catalogError}</p> : null}
      {!providers.length ? <p className="route-status">No provider is configured.</p> : null}
    </div>
    {sudoPrompt}
  </>;
}
