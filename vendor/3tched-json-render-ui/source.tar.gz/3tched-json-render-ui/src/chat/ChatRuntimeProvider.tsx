import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { removeScratchCatalogObject } from "../json-render/references/chat-scratch";
import type { Spec } from "@json-render/core";
import type {
  ChatAdapter,
  ProviderOption,
  RouteSelection,
} from "./chat-adapter";
import { initialCanvasSpec } from "./local-chat-adapter";
import type { ResolvedChatContext } from "./chat-mode";

interface ChatRuntimeValue {
  adapter: ChatAdapter;
  providers: ProviderOption[];
  route: RouteSelection;
  routePending: boolean;
  routeError: string | null;
  routeAttempt: RouteSelection | null;
  routeConfirmed: boolean;
  catalogPending: boolean;
  catalogError: string | null;
  refreshProviders: () => Promise<void>;
  chatContext: ResolvedChatContext | null;
  scopeKey: string;
  setChatContext: (context: ResolvedChatContext) => void;
  canvasSpec: Spec;
  setCanvasSpec: (spec: Spec) => void;
  applyRoute: (selection: RouteSelection) => Promise<void>;
}

const ChatRuntimeContext = createContext<ChatRuntimeValue | null>(null);
const emptyRemoteCanvasSpec: Spec = {
  root: "awaiting-canvas",
  elements: {
    "awaiting-canvas": {
      type: "text",
      props: { text: "Canvas content will appear here when returned by the chat.", className: null },
    },
  },
};

/** The door's resolved session scope is the authority for both thread and Canvas. */
export function chatScopeKey(context: ResolvedChatContext | null, remote: boolean): string {
  if (!remote) return "local";
  if (!context) return "awaiting-door";
  return encodeURIComponent(JSON.stringify([
    context.session_id,
    context.mode,
    context.project_id,
    context.memory_namespace,
  ]));
}

export function chatMessagesPath(streamId: string, scopeKey: string): string {
  return `/streams/${streamId}/scopes/${scopeKey}/messages`;
}

export function ChatRuntimeProvider({
  adapter,
  children,
}: {
  adapter: ChatAdapter;
  children: ReactNode;
}) {
  const [catalog, setCatalog] = useState({ adapter, providers: adapter.providers, pending: false, error: null as string | null });
  const providers = catalog.adapter === adapter ? catalog.providers : adapter.providers;
  const catalogPending = catalog.adapter === adapter && catalog.pending;
  const catalogError = catalog.adapter === adapter ? catalog.error : null;
  const catalogRead = useRef<{ adapter: ChatAdapter; promise: Promise<void> } | null>(null);
  const [contextState, updateChatContext] = useState<{ adapter: ChatAdapter; context: ResolvedChatContext | null }>({ adapter, context: null });
  const currentContext = contextState.adapter === adapter ? contextState.context : null;
  const scopeKey = chatScopeKey(currentContext, adapter.kind === "remote");
  const active = useRef({ adapter, scopeKey, generation: 0 });
  useLayoutEffect(() => {
    if (active.current.adapter !== adapter || active.current.scopeKey !== scopeKey) {
      active.current = { adapter, scopeKey, generation: active.current.generation + 1 };
    }
  }, [adapter, scopeKey]);
  type RouteState = { route: RouteSelection; pending: boolean; error: string | null; attempt: RouteSelection | null; confirmed: boolean };
  const [routes, setRoutes] = useState<{ adapter: ChatAdapter; scopes: Map<string, RouteState> }>({ adapter, scopes: new Map() });
  const setChatContext = useCallback((context: ResolvedChatContext) => {
    // Invalidate requests immediately, before the next render can complete.
    const nextScope = chatScopeKey(context, adapter.kind === "remote");
    if (active.current.scopeKey !== nextScope || active.current.adapter !== adapter) {
      active.current = { adapter, scopeKey: nextScope, generation: active.current.generation + 1 };
    }
    setRoutes(previous => ({ ...previous, scopes: new Map([...previous.scopes].map(([key, value]) => [key, { ...value, pending: false }])) }));
    updateChatContext({ adapter, context });
  }, [adapter]);
  const refreshProviders = (): Promise<void> => {
    if (!adapter.refreshProviders) return Promise.resolve();
    if (catalogRead.current?.adapter === adapter) return catalogRead.current.promise;
    setCatalog({ adapter, providers, pending: true, error: null });
    const promise = adapter.refreshProviders().then((next) => {
      if (active.current.adapter === adapter) setCatalog({ adapter, providers: next, pending: false, error: null });
    }).catch((error: unknown) => {
      if (active.current.adapter === adapter) setCatalog({ adapter, providers, pending: false, error: error instanceof Error ? error.message : "Model catalog refresh failed." });
    }).finally(() => {
      if (catalogRead.current?.promise === promise) catalogRead.current = null;
    });
    catalogRead.current = { adapter, promise };
    return promise;
  };
  const initialProvider = adapter.providers[0];
  const initialRoute = { providerId: initialProvider?.id ?? "", modelId: initialProvider?.models[0]?.id ?? "" };
  const [committed, setCommitted] = useState<{ adapter: ChatAdapter; route: RouteSelection; confirmed: boolean } | null>(null);
  const selected = committed?.adapter === adapter ? committed : { route: initialRoute, confirmed: false };
  const routeState = { ...((routes.adapter === adapter ? routes.scopes.get(scopeKey) : undefined) ?? { pending: false, error: null, attempt: null }), route: selected.route, confirmed: selected.confirmed };
  const { route, pending: routePending, error: routeError, attempt: routeAttempt, confirmed: routeConfirmed } = routeState;
  const [canvasByScope, setCanvasByScope] = useState<Map<string, Spec>>(() => new Map());
  useEffect(() => {
    const key = scopeKey;
    return () => {
      removeScratchCatalogObject(key);
      setCanvasByScope((previous) => {
        if (!previous.has(key)) return previous;
        const next = new Map(previous);
        next.delete(key);
        return next;
      });
    };
  }, [scopeKey]);
  const canvasSpec = canvasByScope.get(scopeKey) ?? (adapter.kind === "remote" ? emptyRemoteCanvasSpec : initialCanvasSpec);
  const setCanvasSpec = (spec: Spec) => {
    setCanvasByScope(previous => new Map(previous).set(scopeKey, spec));
  };

  const applyRoute = async (next: RouteSelection) => {
    if (routePending || (adapter.kind === "remote" && (!currentContext || currentContext.mode === "control_plane"))) return;
    const generation = active.current.generation;
    const matches = () => active.current.adapter === adapter && active.current.scopeKey === scopeKey && active.current.generation === generation;
    const storeRoute = (state: RouteState) => setRoutes(previous => ({
      adapter,
      scopes: new Map(previous.adapter === adapter ? previous.scopes : []).set(scopeKey, state),
    }));
    storeRoute({ ...routeState, pending: true, error: null, attempt: next });
    try {
      const confirmed = await adapter.selectRoute(next);
      if (matches()) {
        setCommitted({ adapter, route: confirmed, confirmed: true });
        storeRoute({ route: confirmed, pending: false, error: null, attempt: next, confirmed: true });
      }
    } catch (error) {
      if (matches()) storeRoute({ ...routeState, pending: false, attempt: next, error: error instanceof Error ? error.message : "Route selection failed." });
    }
  };

  const value: ChatRuntimeValue = {
    adapter,
    providers,
    catalogPending,
    catalogError,
    refreshProviders,
    route,
    routePending,
    routeError,
    routeAttempt,
    routeConfirmed,
    chatContext: currentContext,
    scopeKey,
    setChatContext,
    canvasSpec,
    setCanvasSpec,
    applyRoute,
  };

  return <ChatRuntimeContext.Provider value={value}>{children}</ChatRuntimeContext.Provider>;
}

export function useChatRuntime(): ChatRuntimeValue {
  const value = useContext(ChatRuntimeContext);
  if (!value) {
    throw new Error("useChatRuntime must be used inside ChatRuntimeProvider.");
  }
  return value;
}
