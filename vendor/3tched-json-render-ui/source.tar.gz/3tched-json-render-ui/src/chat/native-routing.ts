import type { DoorClient } from "../grpc/door";
import type { RouteSelection } from "./chat-adapter";
import type { CatalogModel } from "./model-catalog";

const ROUTER_READ = "cap.software.tched-router.router.read@v1";
const NATIVE_PROVIDER_REF = /^[a-z][a-z0-9_-]*\.[a-z][a-z0-9_-]*$/;

export function nativeProfilePath(reference: string, field: "model" | "uri"): string {
  if (!NATIVE_PROVIDER_REF.test(reference)) throw new Error("The catalog contains an invalid native routing binding; expected family.alias.");
  return `providers.models.${reference}.${field}`;
}

export async function readRouterValue(client: DoorClient, path: string): Promise<string> {
  const { result } = await client.call<{ value?: string | null }>("tched_router", "config_get", { path }, ROUTER_READ);
  if (typeof result.value !== "string" || !result.value.trim()) throw new Error(`The router has no configured value for ${path}.`);
  return result.value;
}

function endpoint(value: unknown, label: string): URL {
  if (typeof value !== "string" || !value || value.trim() !== value) throw new Error(`${label} must be an explicit credential-free HTTPS URL.`);
  let url: URL;
  try { url = new URL(value); } catch { throw new Error(`${label} must be an explicit credential-free HTTPS URL.`); }
  if (url.protocol !== "https:" || url.username || url.password || value.includes("?") || value.includes("#") || value.includes("\\") || /%(?:2f|5c)/i.test(url.pathname)) {
    throw new Error(`${label} must be a credential-free HTTPS URL without query, fragment or escaped path separators.`);
  }
  return url;
}

/** Compare explicit endpoint authority, including a complete path segment boundary. */
export function assertInferenceEndpoint(uri: unknown, prefix: unknown): void {
  const allowed = endpoint(prefix, "The model's inference_url_prefix");
  const actual = endpoint(uri, "The native inference URI");
  const path = allowed.pathname.replace(/\/+$/, "") || "/";
  if (actual.origin !== allowed.origin || (path !== "/" && actual.pathname !== path && !actual.pathname.startsWith(`${path}/`))) {
    throw new Error("The native inference URI does not match the model's inference_url_prefix. Configure the intended subscription endpoint before Apply.");
  }
}

export function inferenceEndpointMatches(uri: string, prefix: unknown): boolean {
  try { assertInferenceEndpoint(uri, prefix); return true; } catch { return false; }
}

/** Read only the exact native profile; no family/provider/CP fallback. */
export async function verifiedNativeUri(client: DoorClient, reference: string, prefix: unknown): Promise<string> {
  endpoint(prefix, "The model's inference_url_prefix");
  const uri = await readRouterValue(client, nativeProfilePath(reference, "uri"));
  assertInferenceEndpoint(uri, prefix);
  return uri;
}

export async function readDedicatedRoute(client: DoorClient, role: "control_plane" | "accountability") {
  if (client.isBoundOracle) {
    const { result } = await client.call<{ mode: string; reference: string; model: string; uri: string }>(
      "tched_router", "get_own_agent_route", {}, "cap.software.tched-router.agent.route.self.read@v1",
    );
    if (result.mode !== role) throw new Error("The door returned a different dedicated agent mode. Refresh again.");
    nativeProfilePath(result.reference, "model");
    if (typeof result.model !== "string" || !result.model.trim() || result.model.trim() !== result.model) throw new Error("The dedicated agent has no configured model.");
    endpoint(result.uri, "The native inference URI");
    return { reference: result.reference, modelId: result.model, uri: result.uri };
  }
  const path = `agents.${role}.model_provider`;
  const reference = await readRouterValue(client, path);
  const [modelId, uri] = await Promise.all([
    readRouterValue(client, nativeProfilePath(reference, "model")),
    readRouterValue(client, nativeProfilePath(reference, "uri")),
  ]);
  const [confirmedModel, confirmedUri] = await Promise.all([
    readRouterValue(client, nativeProfilePath(reference, "model")),
    readRouterValue(client, nativeProfilePath(reference, "uri")),
  ]);
  if (await readRouterValue(client, path) !== reference || confirmedModel !== modelId || confirmedUri !== uri) throw new Error(`The ${role === "control_plane" ? "Control Plane" : "Accountability"} selection changed while reading. Refresh again.`);
  return { reference, modelId, uri };
}

/** Accountability has an observed dedicated route, never the dashboard selection. */
export async function verifiedAccountabilityModel(client: DoorClient, models: CatalogModel[]): Promise<RouteSelection> {
  const observed = await readDedicatedRoute(client, "accountability");
  const matches = models.filter(model => model.available && model.model_id === observed.modelId && inferenceEndpointMatches(observed.uri, model.inference_url_prefix));
  if (matches.length !== 1) throw new Error("The dedicated Accountability route has no unique verified catalog model and inference endpoint binding. Configure that dedicated route before sending a message.");
  return { providerId: matches[0].provider_id, modelId: observed.modelId };
}
